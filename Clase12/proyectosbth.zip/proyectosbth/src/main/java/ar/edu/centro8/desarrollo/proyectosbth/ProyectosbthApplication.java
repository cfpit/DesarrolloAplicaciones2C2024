package ar.edu.centro8.desarrollo.proyectosbth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectosbthApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectosbthApplication.class, args);
	}

}
