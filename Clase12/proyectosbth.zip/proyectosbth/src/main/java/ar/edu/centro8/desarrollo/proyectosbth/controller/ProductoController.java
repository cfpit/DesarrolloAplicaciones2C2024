package ar.edu.centro8.desarrollo.proyectosbth.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import ar.edu.centro8.desarrollo.proyectosbth.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbth.service.ProductoService;

@Controller
public class ProductoController {
    @Autowired
	private ProductoService service; 
	
	@RequestMapping("/")
	public String verPaginaPrincipal(Model model) {
		List<Producto> listarProductos = service.listarProductos();
		model.addAttribute("listarProductos", listarProductos);
		
		return "index";
	}
	
	@RequestMapping("/nuevo")
	public String mostrarNuevoProducto(Model model) {
		Producto producto = new Producto();
		model.addAttribute("producto", producto);
		
		return "nuevo_producto";
	}
	
	@RequestMapping(value = "/guardar", method = RequestMethod.POST)
	public String guardarProducto(@ModelAttribute("producto") Producto producto) {
		service.guardarProducto(producto);
		
		return "redirect:/";
	}
	
	@RequestMapping("/editar/{id}")
	public ModelAndView showEditProductPage(@PathVariable(name = "id") int id) {
		ModelAndView mav = new ModelAndView("editar_producto");
		Producto producto = service.listarUnProducto(id);
		mav.addObject("producto", producto);
		
		return mav;
	}
	
	@RequestMapping("/eliminar/{id}")
	public String eliminarProducto(@PathVariable(name = "id") int id) {
		service.eliminarProducto(id);
		return "redirect:/";		
	}
}
