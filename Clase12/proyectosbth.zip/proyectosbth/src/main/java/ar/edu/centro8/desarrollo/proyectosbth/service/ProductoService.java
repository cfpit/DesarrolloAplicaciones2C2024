package ar.edu.centro8.desarrollo.proyectosbth.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ar.edu.centro8.desarrollo.proyectosbth.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbth.repository.ProductoRepository;

@Service
@Transactional
public class ProductoService {
    
    @Autowired
	private ProductoRepository repo;
	
	public List<Producto> listarProductos() {
		return repo.findAll();
	}
	
	public void guardarProducto(Producto producto) {
		repo.save(producto);
	}
	
	public Producto listarUnProducto(long id) {
		return repo.findById(id).get();
	}
	
	public void eliminarProducto(long id) {
		repo.deleteById(id);
	}
}
