package ar.edu.centro8.desarrollo.proyectosbth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectosbthApplicationTests {

	@Test
	void contextLoads() {
	}

}
