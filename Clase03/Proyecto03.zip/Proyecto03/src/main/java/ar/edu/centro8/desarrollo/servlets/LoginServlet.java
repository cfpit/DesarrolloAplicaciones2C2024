package ar.edu.centro8.desarrollo.servlets;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name="Login", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String usuario = req.getParameter("user");
			String clave = req.getParameter("pass");
			
			if(usuario.equals("Juan") && clave.equals("123")) {
				resp.getWriter().println("<h1>Bienvenido!!</h1>");
			}
			else {
				resp.getWriter().println("<h1>No te registro!!</h1>");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
