package ar.edu.centro8.desarrollo.Proyecto01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
