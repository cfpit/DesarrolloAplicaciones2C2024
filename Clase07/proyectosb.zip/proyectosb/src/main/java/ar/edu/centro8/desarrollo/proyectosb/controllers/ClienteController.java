package ar.edu.centro8.desarrollo.proyectosb.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class ClienteController {

    //endpoints
    @GetMapping("/")
    public String saludar() {
        return "Hola Mundo!!";
    }

    @GetMapping("/saludo/{nombre}")
    public String saludar2(@PathVariable String nombre) {
        return "Hola "+nombre+" !!";
    }
    
    @GetMapping("/saludo/{nombre}/{edad}")
    public String saludar3  (   @PathVariable String nombre,
                                @PathVariable int edad
                            ) {
        return "Hola "+nombre+" !!, tenes "+edad+" años";
    }


    
}
