package ar.edu.centro8.desarrollo.proyectosb.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter @Setter
public class Cliente {
    private String nombre;
    private int edad;
}
