package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Stream;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.jpa.JpaPersonaRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.mongo.MongoPersonaRepository;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class PersonaController {

    @Autowired
    @Qualifier("jpaPersonaRepository")
    private JpaPersonaRepository jpaPersonaRepo;

    @Autowired
    @Qualifier("mongoPersonaRepository")
    private MongoPersonaRepository mongoPersonaRepo;

    @GetMapping("/persona/traer")
    public List<Persona> traerPersonas() {
        List<Persona> jpaPersonas = jpaPersonaRepo.findAll();
        List<Persona> mongoPersonas = mongoPersonaRepo.findAll();
        return Stream.concat(jpaPersonas.stream(), mongoPersonas.stream())
                     .collect(Collectors.toList());
    }

    @GetMapping("/persona/traer/{id}")
    public Optional<Persona> traerUnaPersona(@PathVariable Long id) {
        Optional<Persona> jpaPersona = jpaPersonaRepo.findById(id);
        if (jpaPersona.isPresent()) {
            return jpaPersona;
        } else {
            return mongoPersonaRepo.findById(id);
        }
    }
    

    @PostMapping("/persona/crear")
    public void crearPersona(@RequestBody Persona p) {
        jpaPersonaRepo.save(p);
        mongoPersonaRepo.save(p);
    }
    

    @DeleteMapping("/persona/borrar/{id}")
    public String borrarUnaPersona(@PathVariable Long id) {
        jpaPersonaRepo.deleteById(id);
        mongoPersonaRepo.deleteById(id);
        return "persona eliminada correctamente";
    }

    @PutMapping("/persona/actualizar/{id}")
    public String actualizarUnaPersona(@PathVariable Long id, @RequestBody Persona p) {
        // Actualizar en JPA
        Persona personaBuscadaJpa = jpaPersonaRepo.findById(id).orElse(null);
        if (personaBuscadaJpa != null) {
            personaBuscadaJpa.setNombre(p.getNombre());
            personaBuscadaJpa.setEdad(p.getEdad());
            jpaPersonaRepo.save(personaBuscadaJpa);
        }

        // Actualizar en MongoDB
        Persona personaBuscadaMongo = mongoPersonaRepo.findById(id).orElse(null);
        if (personaBuscadaMongo != null) {
            personaBuscadaMongo.setNombre(p.getNombre());
            personaBuscadaMongo.setEdad(p.getEdad());
            mongoPersonaRepo.save(personaBuscadaMongo);
        }

        return "Datos de la persona actualizada correctamente";
    }   
        
}
