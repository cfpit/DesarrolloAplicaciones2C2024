package ar.edu.centro8.desarrollo.proyectosbon2.repository.jpa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;

@Repository("jpaPersonaRepository")
public interface JpaPersonaRepository extends JpaRepository<Persona,Long>{

}
