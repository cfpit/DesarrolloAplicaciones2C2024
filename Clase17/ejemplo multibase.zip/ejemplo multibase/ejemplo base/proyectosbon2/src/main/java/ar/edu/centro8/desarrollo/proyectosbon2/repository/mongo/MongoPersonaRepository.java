package ar.edu.centro8.desarrollo.proyectosbon2.repository.mongo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;

@Repository("mongoPersonaRepository")
public interface MongoPersonaRepository extends MongoRepository<Persona, Long> {
    // Define query methods here if needed
}
