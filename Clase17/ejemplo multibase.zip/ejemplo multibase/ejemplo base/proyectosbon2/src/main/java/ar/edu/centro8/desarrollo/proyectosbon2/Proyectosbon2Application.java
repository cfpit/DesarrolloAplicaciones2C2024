package ar.edu.centro8.desarrollo.proyectosbon2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "ar.edu.centro8.desarrollo.proyectosbon2.repository.jpa")
@EnableMongoRepositories(basePackages = "ar.edu.centro8.desarrollo.proyectosbon2.repository.mongo")
public class Proyectosbon2Application {

    public static void main(String[] args) {
        SpringApplication.run(Proyectosbon2Application.class, args);
    }
}