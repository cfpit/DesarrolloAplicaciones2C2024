package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import ar.edu.centro8.desarrollo.proyectosbon2.dto.PedidoRequest;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Pedido;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PedidoRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.service.PersonaService;
import ar.edu.centro8.desarrollo.proyectosbon2.service.PedidoService;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE })
public class PedidoController {

    @Autowired
    private PedidoRepository pedidoRepo;

    @Autowired
    private ProductoRepository productoRepo;

    @Autowired
    private PersonaService personaService;
    
    @Autowired
    private PedidoService pedidoService;

    @PostMapping("/personas/{id}/pedidos")
    public ResponseEntity<?> crearPedidoParaPersona(@PathVariable Long id, @RequestBody PedidoRequest pedidoRequest) {
        Persona persona = personaService.traerPersona(id);
        if (persona == null) {
            return ResponseEntity.notFound().build();
        }

        Pedido pedido = new Pedido(pedidoRequest.getFecha(), persona);

        Set<Producto> productos = new HashSet<>();
        if (pedidoRequest.getProductos() != null) {
            for (Long idProducto : pedidoRequest.getProductos()) {
                Optional<Producto> productoOpt = productoRepo.findById(idProducto);
                if (productoOpt.isPresent()) {
                    productos.add(productoOpt.get());
                } else {
                    return ResponseEntity.badRequest().body("Producto con ID " + idProducto + " no encontrado");
                }
            }
        }

        pedido.setProductos(productos);
        pedidoService.guardarPedido(pedido);

        return ResponseEntity.ok("Pedido creado exitosamente");
    }
}



/*
 * Resumen Metodo crearPedidoParaPersona:
1.Obtiene la persona por su ID.
2.Crea un nuevo pedido con la fecha y la persona.
3.Obtiene los productos por sus IDs y los asigna al pedido.
4.Guarda el pedido en la base de datos.
5.Devuelve una respuesta indicando el éxito o el fallo de la operación.

Cuerpo del Método
Obtener la Persona:

Persona persona = personaService.traerPersona(id);
if (persona == null) {
    return ResponseEntity.notFound().build();
}

Se utiliza el servicio personaService para obtener la persona con el ID proporcionado.
Si la persona no se encuentra, se devuelve una respuesta 404 Not Found.
Crear el Pedido:

Pedido pedido = new Pedido(pedidoRequest.getFecha(), persona);

Se crea una nueva instancia de Pedido utilizando la fecha proporcionada en pedidoRequest y la persona obtenida.
Obtener y Asignar Productos:

Set<Producto> productos = new HashSet<>();
if (pedidoRequest.getProductos() != null) {
    for (Long idProducto : pedidoRequest.getProductos()) {
        Optional<Producto> productoOpt = productoRepo.findById(idProducto);
        if (productoOpt.isPresent()) {
            productos.add(productoOpt.get());
        } else {
            return ResponseEntity.badRequest().body("Producto con ID " + idProducto + " no encontrado");
        }
    }
}

Se inicializa un conjunto de productos.
Si la lista de productos en pedidoRequest no es nula, se itera sobre cada ID de producto.
Para cada ID de producto, se busca el producto en el repositorio productoRepo.
Si el producto se encuentra, se agrega al conjunto de productos.
Si algún producto no se encuentra, se devuelve una respuesta 400 Bad Request con un mensaje de error.
Asignar Productos al Pedido:

pedido.setProductos(productos);

Se asigna el conjunto de productos al pedido.
Guardar el Pedido:

pedidoService.guardarPedido(pedido);

Se utiliza el servicio pedidoService para guardar el pedido en la base de datos.
Devolver Respuesta:

Si todo va bien, se devuelve una respuesta 200 OK con un mensaje de éxito.
 
 */