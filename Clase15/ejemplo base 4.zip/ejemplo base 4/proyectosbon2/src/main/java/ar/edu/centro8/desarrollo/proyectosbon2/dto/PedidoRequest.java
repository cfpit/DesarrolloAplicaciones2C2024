package ar.edu.centro8.desarrollo.proyectosbon2.dto;

import java.util.Date;
import java.util.Set;

import lombok.Data;

@Data
public class PedidoRequest {
    private Date fecha;
    private Set<Long> productos;
}