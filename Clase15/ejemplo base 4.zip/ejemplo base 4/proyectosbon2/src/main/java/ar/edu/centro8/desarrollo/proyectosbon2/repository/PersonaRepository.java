package ar.edu.centro8.desarrollo.proyectosbon2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;

@Repository
public interface PersonaRepository extends JpaRepository<Persona,Long>{

}
