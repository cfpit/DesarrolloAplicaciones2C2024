package ar.edu.centro8.desarrollo.proyectosbon2.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "productos")
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProducto;

    @Column(name = "articulo", nullable = false)
    private String articulo;

    @Column(name = "precio", nullable = false)
    private Double precio;

    @ManyToMany(mappedBy = "productos", fetch = FetchType.EAGER)
    private Set<Pedido> pedidos = new HashSet<>();

    public Producto(String articulo, Double precio) {
        this.articulo = articulo;
        this.precio = precio;
    }

    public Producto(String articulo, Double precio, Set<Pedido> pedidos) {
        this.articulo = articulo;
        this.precio = precio;
        this.pedidos = pedidos;
    }

    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
        pedido.getProductos().add(this); // Sincronización bidireccional
    }

    public void removerPedido(Pedido pedido) {
        pedidos.remove(pedido);
    }
}