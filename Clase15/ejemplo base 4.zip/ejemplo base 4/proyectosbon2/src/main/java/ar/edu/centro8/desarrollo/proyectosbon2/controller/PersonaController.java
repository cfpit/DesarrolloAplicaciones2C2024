package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Pedido;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PedidoRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PersonaRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.service.PersonaService;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import jakarta.persistence.EntityNotFoundException;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class PersonaController {

    @Autowired
    private PersonaRepository persoRepo;
    
    // @Autowired
    // private ProductoRepository productoRepository;
    // @Autowired
    // private PedidoRepository pedidoRepo;


    @GetMapping("/persona/traer")
    public List<Persona> traerPersonas() {
        return persoRepo.findAll();
    }

    @GetMapping("/persona/traer/{id}")
    public Optional<Persona> traerUnaPersona(@PathVariable Long id) {
        return persoRepo.findById(id);
    }

    @PostMapping("/persona/crear")
    public void crearPersona(@RequestBody Persona p) {
        persoRepo.save(p);
    }

    @DeleteMapping("/persona/borrar/{id}")
    public String borrarUnaPersona(@PathVariable Long id) {
        persoRepo.deleteById(id);
        return "persona eliminada correctamente";
    }

    @PutMapping("/persona/actualizar/{id}")
    public String actualizarUnaPersona(@PathVariable Long id, @RequestBody Persona p) {

        Persona personaBuscada = persoRepo.findById(id).get();

        personaBuscada.setNombre(p.getNombre());
        personaBuscada.setEdad(p.getEdad());

        persoRepo.save(personaBuscada);

        return "Datos de la persona actualizada correctamente";
    }

//     @PostMapping("/persona/{id}/pedidos")
// public ResponseEntity<?> crearPedidoParaPersona(
//         @PathVariable Long id,
//         @RequestBody List<Long> productos) {
    
//     try {
//         Persona persona = persoRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Persona no encontrada"));
        
//         Pedido pedido = new Pedido();
//         pedido.setFecha(new Date());
//         pedido.setPersona(persona);
        
//         Set<Producto> productosSet = new HashSet<Producto>(productos.stream().map(productoId -> 
//             productoRepository.findById(productoId)
//                 .orElseThrow(() -> new EntityNotFoundException("Producto no encontrado"))
//         ).collect(Collectors.toList()));
        
//         pedido.setProductos(productosSet);

//         Pedido savedPedido = pedidoRepo.save(pedido);

//         // Aquí puedes actualizar la tabla de relación (pedido_producto)

//         return ResponseEntity.ok(new ResponseEntity<>(savedPedido, HttpStatus.CREATED));
//     } catch (EntityNotFoundException e) {
//         return ResponseEntity.badRequest().body(new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST));
//     }
// }



    

}
