package ar.edu.centro8.desarrollo.proyectosbon2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.desarrollo.proyectosbon2.model.PedidoProducto; // Ensure this class exists in the specified package

@Repository
public interface PedidoProductoRepository extends JpaRepository<PedidoProducto, Long> {
}