package ar.edu.centro8.desarrollo.proyectosbon2.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Pedido;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PersonaRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PedidoRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class PersonaService {
    @Autowired
    private PersonaRepository personaRepository;

    @Autowired
    private PedidoRepository pedidoRepository;
    
    @Autowired
    private ProductoRepository productoRepository;

    public List<Persona> obtenerPersonas() {
        return personaRepository.findAll();
    }

    public Persona guardarPersona(Persona persona) {
        return personaRepository.save(persona);
    }

    public boolean eliminarPersona(Long id) {
        try {
            personaRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Persona traerPersona(Long id) {
        return personaRepository.findById(id).orElse(null);
    }

    public Persona editarPersona(Long idOriginal, String nuevoNombre) {
        Persona persona = traerPersona(idOriginal);
        if (persona != null) {
            persona.setNombre(nuevoNombre);
            return guardarPersona(persona);
        }
        return null;
    }

    public Pedido guardarPedido(Pedido pedido) {
        Pedido savedPedido = pedidoRepository.save(pedido);

        for (Producto producto : savedPedido.getProductos()) {
            producto.getPedidos().add(savedPedido);
            productoRepository.save(producto);
        }
    
        return savedPedido;
    }
}