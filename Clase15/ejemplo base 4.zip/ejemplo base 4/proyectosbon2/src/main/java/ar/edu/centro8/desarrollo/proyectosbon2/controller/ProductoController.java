package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import jakarta.persistence.ManyToMany;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import org.springframework.web.bind.annotation.RequestMethod;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class ProductoController {

    @Autowired
    private ProductoRepository productoRepo;

    @GetMapping("/producto/traer")
    public List<Producto> traerProductos() {
        return productoRepo.findAll();
    }

    @GetMapping("/producto/traer/{id}")
    public Optional<Producto> traerUnProducto(@PathVariable Long id) {
        return productoRepo.findById(id);
    }

    @PostMapping("/producto/crear")
    public void crearProducto(@RequestBody Producto p) {
        productoRepo.save(p);
    }

    @DeleteMapping("/producto/borrar/{id}")
    public String borrarUnProducto(@PathVariable Long id) {
        productoRepo.deleteById(id);
        return "Producto eliminado correctamente";
    }

    @PutMapping("/producto/actualizar/{id}")
    public String actualizarUnProducto(@PathVariable Long id, @RequestBody Producto p) {

        Producto productoBuscado = productoRepo.findById(id).get();

        productoBuscado.setArticulo(p.getArticulo());
        productoBuscado.setPrecio(p.getPrecio());

        productoRepo.save(productoBuscado);
        
        return "Datos del Producto actualizados correctamente";

    }


}
