package ar.edu.centro8.desarrollo.proyectosbon2.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Pedido;
import ar.edu.centro8.desarrollo.proyectosbon2.model.Producto;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.PedidoRepository;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ProductoRepository productoRepository;

    public List<Pedido> obtenerPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedido guardarPedido(Pedido pedido) {
        Pedido savedPedido = pedidoRepository.save(pedido);

        for (Producto producto : savedPedido.getProductos()) {
            producto.getPedidos().add(savedPedido);
            productoRepository.save(producto);
        }
    
        return savedPedido;
    }

    public Pedido traerPedido(Long id) {
        return pedidoRepository.findById(id).orElse(null);
    }

    public boolean eliminarPedido(Long id) {
        try {
            pedidoRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}