package ar.edu.centro8.desarrollo.proyectosbon2.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "pedidos")
@Getter
@Setter
@NoArgsConstructor
@Data
// es útil cuando deseas que tu aplicación ignore propiedades desconocidas en el JSON de entrada, evitando errores de deserialización y haciendo que tu aplicación sea más robusta y flexible frente a cambios en el formato JSON.
@JsonIgnoreProperties(ignoreUnknown = true)
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPedido;

    @Column(name = "fecha", nullable = false)
    private Date fecha;

    @ManyToOne
    @JoinColumn(name = "id_persona", referencedColumnName = "idPersona")
    private Persona persona;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "pedido_producto", joinColumns = @JoinColumn(name = "id_pedido", referencedColumnName = "idPedido"), inverseJoinColumns = @JoinColumn(name = "id_producto", referencedColumnName = "idProducto"))
    private Set<Producto> productos = new HashSet<>();

    public Pedido(Date fecha, Persona persona) {
        this.fecha = fecha;
        this.persona = persona;
    }

    public Pedido(Date fecha, Set<Producto> productos) {
        this.fecha = fecha;
        this.productos = productos;
    }

    public Pedido(Date fecha) {
        this.fecha = fecha;
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
        producto.getPedidos().add(this); // Sincronización bidireccional
    }

    public void removerProducto(Producto producto) {
        productos.remove(producto);
    }
}