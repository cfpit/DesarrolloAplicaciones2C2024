document.addEventListener("DOMContentLoaded", () => {
    fetchEmpleados()
})

function fetchEmpleados() {
    fetch('http://localhost:8080/empleados')
        .then(response => response.json())
        .then(data => {
            const empleadosBody = document.getElementById('empleados-body');
            empleadosBody.innerHTML = ''
            data.forEach(empleado => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${empleado.idEmpleado}</td>
                    <td>${empleado.apellido}</td>
                    <td>${empleado.legajo}</td>
                    <td>${empleado.turno}</td>
                    <td>${empleado.sector.nombre}</td>
                `
                empleadosBody.appendChild(row)
            })
        })
        .catch(error => console.error('Error al obtener los empleados:', error))
}