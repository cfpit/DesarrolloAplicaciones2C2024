package ar.edu.centro8.desarrollo.proyectosbrelacion1an.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Empleado;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.repository.EmpleadoRepository;

@Service
public class EmpleadoService {

    @Autowired
    private  EmpleadoRepository empleadoRepository;

    // public EmpleadoService(EmpleadoRepository empleadoRepository) {
    //     this.empleadoRepository = empleadoRepository;
    // }

    public List<Empleado> getAllEmpleados() {
        return empleadoRepository.findAll();
    }

    public Empleado getEmpleadoById(Long id) {
        return empleadoRepository.findById(id).orElse(null); // Devuelve null si el empleado no se encuentra        
    }

    public Empleado saveEmpleado(Empleado empleado) {
        return empleadoRepository.save(empleado);
    }

    public void deleteEmpleado(Long id) {
        empleadoRepository.deleteById(id);
    }

    // public List<Empleado> getEmpleadosBySector(Long idSector) {
    //     return empleadoRepository.findBySectorIdSector(idSector);
    // }

    // public List<Empleado> getEmpleadosBySector(String nombreSector) {
    //     return empleadoRepository.findBySectorNombre(nombreSector);
    // }

    // public List<Empleado> getEmpleadosBySectorAndNombre(Long idSector, String nombre) {
    //     return empleadoRepository.findBySectorIdSectorAndNombre(idSector, nombre);
    // }

    // public List<Empleado> getEmpleadosBySectorAndNombre(String nombreSector, String nombre) {
    //     return empleadoRepository.findBySectorNombreAndNombre(nombreSector, nombre);
    // }

}