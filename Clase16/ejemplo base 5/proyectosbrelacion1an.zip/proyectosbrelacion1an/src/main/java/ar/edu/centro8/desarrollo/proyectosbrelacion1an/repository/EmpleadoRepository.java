package ar.edu.centro8.desarrollo.proyectosbrelacion1an.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Empleado;

public interface EmpleadoRepository extends JpaRepository<Empleado, Long> {

}