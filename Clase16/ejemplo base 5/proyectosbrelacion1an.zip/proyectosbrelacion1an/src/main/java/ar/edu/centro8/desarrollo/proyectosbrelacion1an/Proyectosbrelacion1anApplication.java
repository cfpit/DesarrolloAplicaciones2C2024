package ar.edu.centro8.desarrollo.proyectosbrelacion1an;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectosbrelacion1anApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyectosbrelacion1anApplication.class, args);
	}

}
