package ar.edu.centro8.desarrollo.proyectosbrelacion1an.controller;



import org.springframework.web.bind.annotation.*;
import java.util.List;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Sector;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.service.SectorService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE })
public class SectorController {

    private final SectorService sectorService;

    public SectorController(SectorService sectorService) {
        this.sectorService = sectorService;
    }

    @GetMapping("/sectores")
    public List<Sector> getAllSectores() {
        return sectorService.getAllSectores();
    }

    @GetMapping("/sectores/{id}")
    public Sector getSectorById(@PathVariable Long id) {
        return sectorService.getSectorById(id);
    }

    @PostMapping("/sectores")
    public Sector createSector(@RequestBody Sector sector) {
        return sectorService.saveSector(sector);
    }

    @DeleteMapping("/sectores/{id}")
    public void deleteSector(@PathVariable Long id) {
        sectorService.deleteSector(id);
    }
}
