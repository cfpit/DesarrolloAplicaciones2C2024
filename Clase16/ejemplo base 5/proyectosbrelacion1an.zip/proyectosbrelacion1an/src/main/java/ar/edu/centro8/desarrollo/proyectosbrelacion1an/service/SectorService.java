package ar.edu.centro8.desarrollo.proyectosbrelacion1an.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Empleado;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Sector;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.repository.SectorRepository;

@Service
public class SectorService {

    @Autowired
    private  SectorRepository sectorRepository;

    // public SectorService(SectorRepository sectorRepository) {
    //     this.sectorRepository = sectorRepository;
    // }

    public List<Sector> getAllSectores() {
        return sectorRepository.findAll();
    }

    public Sector getSectorById(Long id) {
        return sectorRepository.findById(id).orElse(null); // Devuelve null si el sector no se encuentra        
    }

    public Sector saveSector(Sector sector) {
        return sectorRepository.save(sector);
    }

    public void deleteSector(Long id) {
        sectorRepository.deleteById(id);
    }

    
}