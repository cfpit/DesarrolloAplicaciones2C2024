package ar.edu.centro8.desarrollo.proyectosbrelacion1an.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "empleados")
public class Empleado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEmpleado;

    private String apellido;
    private String legajo;
    private String turno;

    @ManyToOne
    @JoinColumn(name = "id_sector", referencedColumnName = "idSector")
    private Sector sector;

    public Empleado() {
    }
    
}
