package ar.edu.centro8.desarrollo.proyectosbrelacion1an.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.centro8.desarrollo.proyectosbrelacion1an.model.Sector;

public interface SectorRepository extends JpaRepository<Sector, Long> {

}


