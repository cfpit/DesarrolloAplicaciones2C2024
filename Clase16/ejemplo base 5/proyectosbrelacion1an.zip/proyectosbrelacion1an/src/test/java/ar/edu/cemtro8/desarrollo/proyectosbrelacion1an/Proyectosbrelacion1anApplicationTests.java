package ar.edu.cemtro8.desarrollo.proyectosbrelacion1an;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyectosbrelacion1anApplicationTests {

	@Test
	void contextLoads() {
	}

}
