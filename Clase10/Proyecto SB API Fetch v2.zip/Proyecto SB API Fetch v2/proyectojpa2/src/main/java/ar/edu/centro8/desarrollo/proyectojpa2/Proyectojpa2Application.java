package ar.edu.centro8.desarrollo.proyectojpa2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectojpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyectojpa2Application.class, args);
	}

}
