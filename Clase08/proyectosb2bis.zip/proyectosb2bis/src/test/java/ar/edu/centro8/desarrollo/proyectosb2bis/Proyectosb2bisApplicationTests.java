package ar.edu.centro8.desarrollo.proyectosb2bis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyectosb2bisApplicationTests {

	@Test
	void contextLoads() {
	}

}
