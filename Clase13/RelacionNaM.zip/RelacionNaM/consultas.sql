SELECT * FROM jpa_relaciones3.curso;

SELECT * FROM jpa_relaciones3.estudiante;

SELECT * FROM jpa_relaciones3.estudiante_curso;	