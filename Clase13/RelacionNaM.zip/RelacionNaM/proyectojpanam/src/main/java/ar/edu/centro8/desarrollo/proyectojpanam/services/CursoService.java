package ar.edu.centro8.desarrollo.proyectojpanam.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpanam.dto.CursoRequestDTO;
import ar.edu.centro8.desarrollo.proyectojpanam.dto.EstudianteRequestDTO;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Curso;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Estudiante;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.CursoRepository;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.EstudianteRepository;
import jakarta.transaction.Transactional;

@Service
public class CursoService {
    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private EstudianteRepository estudianteRepository;

    @Transactional
    public Curso crearCursoConEstudiante(CursoRequestDTO cursoRequest) {
        Curso curso = new Curso(cursoRequest.getNombre());
        
        for (EstudianteRequestDTO estudiante : cursoRequest.getEstudiantes()) {
            Estudiante estudianteNuevo = new Estudiante(estudiante.getNombre());
            estudianteNuevo.agregarCurso(curso);
            curso.agregarEstudiante(estudianteNuevo);
            estudianteRepository.save(estudianteNuevo);
        }
        
        return cursoRepository.save(curso);
    }
}
