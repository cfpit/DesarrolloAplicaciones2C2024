/*
 La llamada optionalEstudiante.isPresent() realiza la siguiente función:

Comprueba si hay un valor presente dentro del Optional.
Devuelve un booleano:
Si hay un valor presente, devuelve true.
Si no hay ningún valor, devuelve false.
Es una forma de verificar si el Optional contiene algún elemento sin acceder directamente al contenido.



Optional es una clase en Java que representa un valor que puede o no estar presente. Es parte del paquete java.util y fue introducido en Java 8. Sus principales características son:

Representa un valor que puede o no estar presente.
Permite manejar casos donde un valor podría no existir sin necesidad de usar null.
Ofrece métodos para verificar si tiene un valor y acceder a él de manera segura.
Es particularmente útil en combinación con funciones lambda y expresiones de interfaz.
Es usado por Spring Data JPA en métodos como findById() para indicar que el resultado puede ser nulo.
 */

package ar.edu.centro8.desarrollo.proyectojpanam.controllers;

import ar.edu.centro8.desarrollo.proyectojpanam.models.Curso;
import ar.edu.centro8.desarrollo.proyectojpanam.models.Estudiante;
import ar.edu.centro8.desarrollo.proyectojpanam.repositories.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {

    @Autowired
    private EstudianteRepository estudianteRepository;

    @GetMapping
    public void traerEstudiantes() {
        List<Estudiante> estudiantes = estudianteRepository.findAll();
    }

    @GetMapping("/{id}")
    public void traerEstudiantePorId(@PathVariable Long id) {
        estudianteRepository.findById(id);
    }

    @PostMapping
    public void crearEstudiante(@RequestBody Estudiante estudiante) {
        estudianteRepository.save(estudiante);
    }

    @PutMapping("/editar/estudiante/{id_original}")
    public void editarEstudiante(@PathVariable Long id_original,
            @RequestParam(required = false, name = "id") Long nuevaId,
            @RequestParam(required = false, name = "nombre") String nuevoNombre) {
        Optional<Estudiante> optionalEstudiante = estudianteRepository.findById(id_original);
        if (optionalEstudiante.isPresent()) {
            Estudiante existingEstudiante = optionalEstudiante.get();
            existingEstudiante.setNombre(nuevoNombre);
            estudianteRepository.save(existingEstudiante);
        } else {
            // Manejar el caso en que el estudiante no existe
        }

    }

    @DeleteMapping("/{id}")
    public void eliminarEstudiante(@PathVariable Long id) {
        estudianteRepository.deleteById(id);
    }

}
