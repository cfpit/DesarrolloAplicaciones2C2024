SELECT * FROM jpa_relaciones.auto;	

SELECT * FROM jpa_relaciones.motor;	

-- relacion 
select *
from auto a
inner join motor m on m.id_motor = a.id_motor;

