package ar.edu.centro8.desarrollo.proyectojpa1a1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyectojpa1a1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
