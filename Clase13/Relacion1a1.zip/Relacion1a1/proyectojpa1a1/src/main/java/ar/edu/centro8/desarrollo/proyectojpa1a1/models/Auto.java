package ar.edu.centro8.desarrollo.proyectojpa1a1.models;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapsId;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "auto")
@Getter @Setter
@NoArgsConstructor
public class Auto {
    // @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)
    // private Long idAuto;

    //relacion bidireccional pk compartida
    @Id
    @Column(name = "id_motor")
    private Long idAuto;

    @Column(name = "marca", nullable = false)
    private String marca;

    @Column(name = "precio", nullable = false)
    private BigDecimal precio;


    //RELACION UNIDIRECCIONAL FK - PK
    // @OneToOne(fetch = FetchType.EAGER)
    // @JoinColumn(name = "id_motor", referencedColumnName = "idMotor")
    // private Motor motor;

    
    //RELACION BIDIRECCIONAL FK - PK
    // @OneToOne(cascade = CascadeType.ALL, optional = false)
    // @JsonBackReference
    // @JoinColumn(name = "id_motor")
    // private Motor motor;

    //RELACION BIDIRECCIONAL PK COMPARTIDA
    @OneToOne(cascade = CascadeType.ALL, optional = false)
    @JsonBackReference
    @MapsId
    @JoinColumn(name = "id_motor")
    private Motor motor;


    public Auto(String marca, BigDecimal precio, Motor motor) {
        this.marca = marca;
        this.precio = precio;
        this.motor = motor;
    }
}


/*cascade = CascadeType.ALL:
Permite que todas las operaciones de cascada se apliquen a la entidad relacionada.
Con ALL, significa que cualquier operación realizada en la entidad principal también afectará a la entidad secundaria.
optional = false:
Indica que la relación es obligatoria (no puede ser nula). */
