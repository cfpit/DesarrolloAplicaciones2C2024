package ar.edu.centro8.desarrollo.proyectojpa1a1.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "motor")
@Getter @Setter
@NoArgsConstructor
public class Motor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idMotor;

    @Column(name = "cilindrada", nullable = false)
    private Integer cilindrada;

    public Motor(Integer cilindrada) {
        this.cilindrada = cilindrada;
    }

    //RELACION UNIDIRECCIONAL: sin codigo

    
    //RELACION BIDIRECCIONAL FK - PK
    // @OneToOne(mappedBy = "motor", cascade = CascadeType.ALL)
    // private Auto auto;


    //RELACION BIDIRECCIONAL PK COMPARTIDA
    // @OneToOne(mappedBy = "motor", cascade = CascadeType.ALL)
    // @PrimaryKeyJoinColumn
    // private Auto auto;

    //implementacion de equals y hashcode
    //valido para relaciones bidireccionales
    // @Override
    // public int hashCode() {
    //     final int prime = 31;
    //     int result = 1;
    //     result = prime * result + ((idMotor == null) ? 0 : idMotor.hashCode());
    //     result = prime * result + ((cilindrada == null) ? 0 : cilindrada.hashCode());
    //     result = prime * result + ((auto == null) ? 0 : auto.hashCode());
    //     return result;
    // }

    // @Override
    // public boolean equals(Object obj) {
    //     if (this == obj)
    //         return true;
    //     if (obj == null)
    //         return false;
    //     if (getClass() != obj.getClass())
    //         return false;
    //     Motor other = (Motor) obj;
    //     if (idMotor == null) {
    //         if (other.idMotor != null)
    //             return false;
    //     } else if (!idMotor.equals(other.idMotor))
    //         return false;
    //     if (cilindrada == null) {
    //         if (other.cilindrada != null)
    //             return false;
    //     } else if (!cilindrada.equals(other.cilindrada))
    //         return false;
    //     if (auto == null) {
    //         if (other.auto != null)
    //             return false;
    //     } else if (!auto.equals(other.auto))
    //         return false;
    //     return true;
    // } 

}
