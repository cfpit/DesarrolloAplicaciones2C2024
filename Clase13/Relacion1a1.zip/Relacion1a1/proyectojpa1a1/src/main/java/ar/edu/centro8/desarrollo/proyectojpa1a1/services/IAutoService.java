package ar.edu.centro8.desarrollo.proyectojpa1a1.services;

import java.util.List;
import java.math.BigDecimal;

import ar.edu.centro8.desarrollo.proyectojpa1a1.models.Auto;

public interface IAutoService {
    //método para traer a todas las personas
    //lectura
    public List<Auto> obtenerAutos();

    //alta
    public Auto guardarAuto(Auto auto);

    //baja
    public boolean eliminarAuto(Long id);

    //lectura de un solo objeto
    public Auto traerAuto(Long id);

    //edición/modificación
    public Auto editarAuto(Long idOriginal, Long idNueva,
                            String nuevaMarca,
                            BigDecimal nuevoPrecio);
}
