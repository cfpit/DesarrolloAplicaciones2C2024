package ar.edu.centro8.desarrollo.proyectojpa1an.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.desarrollo.proyectojpa1an.models.Concesionaria;

public interface ConcesionariaRepository extends JpaRepository<Concesionaria,Long>{

}
