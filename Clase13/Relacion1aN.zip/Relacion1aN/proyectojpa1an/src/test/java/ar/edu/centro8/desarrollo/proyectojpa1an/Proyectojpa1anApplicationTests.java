package ar.edu.centro8.desarrollo.proyectojpa1an;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyectojpa1anApplicationTests {

	@Test
	void contextLoads() {
	}

}
